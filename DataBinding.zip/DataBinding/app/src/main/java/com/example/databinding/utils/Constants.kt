package com.example.databinding.utils

object Constants {

    const val DATABASE_NAME = "testing"

    const val USER_TABLE = "user"
}